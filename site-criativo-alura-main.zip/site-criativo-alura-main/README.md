# Site da Equipe Alura Start! 

Fiz esse site para divulgar a equipe de trabalho incrivel que eu participo! 

Prototipo criado <a href="https://www.figma.com/file/fnayTC7vCARDn1aYsc6OGw/Prototipo-site?node-id=0%3A1" target="_blank" rel="noopener noreferrer">Figma</a>

Links das imagens e icones: 

- <a href="https://www.flaticon.com/packs/social-media-51?word=ui" title="Social media">Icones criados por Freepik - Flaticon</a>
- <a href="https://storyset.com/education">Imagens retiradas do site Storyset</a>
